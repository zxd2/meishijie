import React from 'react';
class Mime extends React.Component {
   render(){
       return(
           <div>我的</div>
       )
   }
}
export default Mime