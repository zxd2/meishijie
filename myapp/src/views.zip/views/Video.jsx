import React from 'react';

class Video extends React.Component {
   render(){
       return(
           <div>视频</div>
       )
   }
}
export default Video