import React from 'react';
class Menu extends React.Component {
   render(){
       return(
           <div>菜单</div>
       )
   }
}
export default Menu