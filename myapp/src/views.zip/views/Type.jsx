import React from 'react';

class Type extends React.Component {
   render(){
       return(
           <div>分类</div>
       )
   }
}
export default Type