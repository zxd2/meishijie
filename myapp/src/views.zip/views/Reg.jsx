import React from 'react';

class Reg extends React.Component {
   render(){
       return(
           <div>注册</div>
       )
   }
}
export default Reg